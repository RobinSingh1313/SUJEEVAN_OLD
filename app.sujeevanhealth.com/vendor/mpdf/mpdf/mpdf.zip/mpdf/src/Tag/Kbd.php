<?php

namespace Mpdf\Tag;

class Kbd extends InlineTag
{


}
